This's WN18RR data set!
The details of it can be get by this paper titled:Tim Dettmers, Pasquale Minervini,Pontus Stenetorp,Sebastian Riedel. Convolutional 2D Knowledge Graph Embeddings,2018, Association for the Advancement of Artificial Intelligence (www.aaai.org).
